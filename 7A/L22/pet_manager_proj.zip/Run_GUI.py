# -*- coding: utf-8 -*-
# 先安装库在pip install PySimpleGUI
import PySimpleGUI as sg      # 导入库
# 注意：设置元素的key名称，后续可获取它对应的value,或设置其显示的内容

# 定义窗口的内容
layout = [[sg.Text("请输入姓名")],   # 按行、列排版
          [sg.Text("姓名:"), sg.Input(do_not_clear=True, key='_NAME_')],
          [sg.Text('', key='_OUTPUT_')],
          [sg.Button('确定'), sg.Button('取消')]]

# 创建窗口：
window = sg.Window('获取输入，设置输出', layout)

while True:  # 事件循环
    event, values = window.read()  # 获取文本框输入内容
    if event == sg.WIN_CLOSED or event == '取消':
        #判断是否点击了关闭窗口或取消按钮
        break

    # 设置文本框信息
    if event == '确定':
        message = '你好：' + values['_NAME_']
        window.Element('_OUTPUT_').Update(message)

window.close()  # 关闭窗口
